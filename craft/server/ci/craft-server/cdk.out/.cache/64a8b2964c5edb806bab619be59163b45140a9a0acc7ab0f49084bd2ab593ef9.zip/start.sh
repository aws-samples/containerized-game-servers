#!/bin/bash

/monitor_active_game_sessions.sh&
python /server.py
